(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[6687],{45370:function(e,t,r){(window.__NEXT_P=window.__NEXT_P||[]).push(["/management/service-details",function(){return r(9450)}])},36039:function(e,t,r){"use strict";var a=r(13077),l=r(85893);t.Z=(0,a.Z)((0,l.jsx)("path",{d:"M12 2C6.47 2 2 6.47 2 12s4.47 10 10 10 10-4.47 10-10S17.53 2 12 2z"}),"Circle")},32602:function(e,t,r){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),function(e,t){for(var r in t)Object.defineProperty(e,r,{enumerable:!0,get:t[r]})}(t,{default:function(){return s},noSSR:function(){return n}});let a=r(38754);r(85893),r(67294);let l=a._(r(35491));function i(e){return{default:(null==e?void 0:e.default)||e}}function n(e,t){return delete t.webpack,delete t.modules,e(t)}function s(e,t){let r=l.default,a={loading:e=>{let{error:t,isLoading:r,pastDelay:a}=e;return null}};e instanceof Promise?a.loader=()=>e:"function"==typeof e?a.loader=e:"object"==typeof e&&(a={...a,...e});let s=(a={...a,...t}).loader;return(a.loadableGenerated&&(a={...a,...a.loadableGenerated},delete a.loadableGenerated),"boolean"!=typeof a.ssr||a.ssr)?r({...a,loader:()=>null!=s?s().then(i):Promise.resolve(i(()=>null))}):(delete a.webpack,delete a.modules,n(r,a))}("function"==typeof t.default||"object"==typeof t.default&&null!==t.default)&&void 0===t.default.__esModule&&(Object.defineProperty(t.default,"__esModule",{value:!0}),Object.assign(t.default,t),e.exports=t.default)},1159:function(e,t,r){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),Object.defineProperty(t,"LoadableContext",{enumerable:!0,get:function(){return a}});let a=r(38754)._(r(67294)).default.createContext(null)},35491:function(e,t,r){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),Object.defineProperty(t,"default",{enumerable:!0,get:function(){return h}});let a=r(38754)._(r(67294)),l=r(1159),i=[],n=[],s=!1;function d(e){let t=e(),r={loading:!0,loaded:null,error:null};return r.promise=t.then(e=>(r.loading=!1,r.loaded=e,e)).catch(e=>{throw r.loading=!1,r.error=e,e}),r}class o{promise(){return this._res.promise}retry(){this._clearTimeouts(),this._res=this._loadFn(this._opts.loader),this._state={pastDelay:!1,timedOut:!1};let{_res:e,_opts:t}=this;e.loading&&("number"==typeof t.delay&&(0===t.delay?this._state.pastDelay=!0:this._delay=setTimeout(()=>{this._update({pastDelay:!0})},t.delay)),"number"==typeof t.timeout&&(this._timeout=setTimeout(()=>{this._update({timedOut:!0})},t.timeout))),this._res.promise.then(()=>{this._update({}),this._clearTimeouts()}).catch(e=>{this._update({}),this._clearTimeouts()}),this._update({})}_update(e){this._state={...this._state,error:this._res.error,loaded:this._res.loaded,loading:this._res.loading,...e},this._callbacks.forEach(e=>e())}_clearTimeouts(){clearTimeout(this._delay),clearTimeout(this._timeout)}getCurrentValue(){return this._state}subscribe(e){return this._callbacks.add(e),()=>{this._callbacks.delete(e)}}constructor(e,t){this._loadFn=e,this._opts=t,this._callbacks=new Set,this._delay=null,this._timeout=null,this.retry()}}function c(e){return function(e,t){let r=Object.assign({loader:null,loading:null,delay:200,timeout:null,webpack:null,modules:null},t),i=null;function d(){if(!i){let t=new o(e,r);i={getCurrentValue:t.getCurrentValue.bind(t),subscribe:t.subscribe.bind(t),retry:t.retry.bind(t),promise:t.promise.bind(t)}}return i.promise()}if(!s){let e=r.webpack?r.webpack():r.modules;e&&n.push(t=>{for(let r of e)if(t.includes(r))return d()})}function c(e,t){!function(){d();let e=a.default.useContext(l.LoadableContext);e&&Array.isArray(r.modules)&&r.modules.forEach(t=>{e(t)})}();let n=a.default.useSyncExternalStore(i.subscribe,i.getCurrentValue,i.getCurrentValue);return a.default.useImperativeHandle(t,()=>({retry:i.retry}),[]),a.default.useMemo(()=>{var t;return n.loading||n.error?a.default.createElement(r.loading,{isLoading:n.loading,pastDelay:n.pastDelay,timedOut:n.timedOut,error:n.error,retry:i.retry}):n.loaded?a.default.createElement((t=n.loaded)&&t.default?t.default:t,e):null},[e,n])}return c.preload=()=>d(),c.displayName="LoadableComponent",a.default.forwardRef(c)}(d,e)}function u(e,t){let r=[];for(;e.length;){let a=e.pop();r.push(a(t))}return Promise.all(r).then(()=>{if(e.length)return u(e,t)})}c.preloadAll=()=>new Promise((e,t)=>{u(i).then(e,t)}),c.preloadReady=e=>(void 0===e&&(e=[]),new Promise(t=>{let r=()=>(s=!0,t());u(n,e).then(r,r)})),window.__NEXT_PRELOADREADY=c.preloadReady;let h=c},20142:function(e,t,r){"use strict";var a=r(85893),l=r(75216),i=r(63792),n=r(59195);r(67294);var s=r(27684);let d=[{display:"flex",alignItem:"center",field:"avatar",headerName:"",minWidth:80,groupable:!1,aggregable:!1,sortable:!1,width:80,valueGetter:(e,t)=>`${t?.nickName}`,renderCell:e=>{let{firstName:t,lastName:r,backColor:a,foreColor:l,avatar:i}=e.row;return(0,n.Ew)(i)?(0,n.gk)(t,r,a,l):(0,n.Ik)(i)}},{field:"nickName",headerName:"Name",minWidth:115,width:115,flex:1}];t.Z=({onSelect:e})=>{let{technicians:t}=(0,i.Z)();return(0,a.jsx)(a.Fragment,{children:(0,a.jsx)(l.Z,{gridProps:{...s.tyM},columns:d,countRow:!1,dataRow:t,onRowClick:e})})}},9450:function(e,t,r){"use strict";r.r(t),r.d(t,{default:function(){return W}});var a=r(85893),l=r(67294),i=r(41248),n=r(5152),s=r.n(n),d=r(90475),o=r(8188),c=r(28886),u=r(59195),h=r(58656),m=r(27603),p=r(4762),g=r(70405),f=r(58531),b=r(68573),x=r(27684),y=r(18704),_=r(75216),v=r(22507),E=({data:e,allTechnician:t=!1,handleOnRowClick:r})=>{let{loading:l}=(0,i.v9)(e=>e[c._.REDUX]),{loading:n}=(0,i.v9)(e=>e[y._.REDUX]),{companyProfileResult:s}=(0,i.v9)(e=>e[o._.REDUX]),d=[{field:"nickName",headerName:"Technician",minWidth:120,groupable:!1,aggregable:!1,hideable:!0},{field:"ticketNumber",headerName:"Ticket#",minWidth:80,groupable:!1,aggregable:!1},{field:"itemName",headerName:"Service",minWidth:300,flex:1,groupable:!1,aggregable:!1,valueFormatter:(e,t)=>`${t.menuItemType===x.UIn.ServicePackageItem||t.menuItemType===x.UIn.PrePaidPackageItem?"==":""}${e??""}`},{field:"qty",headerName:"Qty",width:70,groupable:!1,type:x.ga8.Number},{field:"originalPrice",headerName:"Price",minWidth:100,width:120,align:"right",groupable:!1,type:x.ga8.Number,headerAlign:"right",valueFormatter:e=>(0,u.xG)(e)},{field:"nonCashTip",headerName:"NC Tips",minWidth:100,groupable:!1,type:x.ga8.Number,align:"right",headerAlign:"right",valueFormatter:e=>(0,u.xG)(e)},{field:"originalDiscount",headerName:"Discount Total",minWidth:160,align:"right",groupable:!1,type:x.ga8.Number,headerAlign:"right",valueFormatter:e=>(0,u.xG)(e)},{field:"serviceChargeTotal",headerName:"Item Supply Fee",minWidth:180,groupable:!1,type:x.ga8.Number,align:"right",headerAlign:"right",valueFormatter:e=>(0,u.xG)(e)},{field:"supplyCharge",headerName:"Ticket Supply Fee",minWidth:180,groupable:!1,type:x.ga8.Number,align:"right",headerAlign:"right",valueFormatter:e=>(0,u.xG)(e)}];return(0,a.jsx)(_.Z,{fullHeight:!0,columns:d,gridProps:{...x.tyM,disableAggregation:!1,initialState:{aggregation:{model:{serviceChargeTotal:"sum",qty:"sum",originalPrice:"sum",nonCashTip:"sum",originalDiscount:"sum",supplyCharge:"sum"}}}},customFilter:t?null:[(0,a.jsx)(v.Z,{type:"horizontal",firstDayOfWeek:s?.weekStartsOn},"date-range")],dataRow:e??[],loading:l||n,onRowClick:r})},P=r(60762),S=({id:e})=>{let{dataBillServiceDetails:t}=(0,i.v9)(e=>e[y._.REDUX]),{companyProfileResult:r}=(0,i.v9)(e=>e[o._.REDUX]),[n,s]=(0,l.useState)("");return(0,l.useEffect)(()=>{if((0,u.K0)(t)){if(!(0,u.K0)(t?.dataSource)){s("");return}let e=h.ZP.get(d.P.QrCode),a=t?.dataSource;(0,u.Ew)(r?.receiptMessage?.qrCodeCustomerReceipt)||(a=t?.dataSource?.replace("</body>",`<div class='qr'>
						<img src=${e} />
						</div></div></body>`)),s(a)}},[r?.receiptMessage?.qrCodeCustomerReceipt,t]),(0,a.jsx)(l.Fragment,{children:(0,a.jsx)(P.Z,{className:"render-bill",dangerouslySetInnerHTML:{__html:(0,u.K0)(t)?n:""}})})},k=r(9677),w=r(60056),T=r(68780),j=r(20142),D=r(69364),C=r(79010),I=r(85017),N=r(91309),R=r(30381),A=r.n(R);let Z=(0,p.Z)({VIEW_ALL_SERVICE_DETAILS:(0,a.jsx)(D.Fo,{children:(0,a.jsx)(()=>{let e=(0,i.I0)(),t=(0,l.useRef)(""),{getDataResult:r}=(0,i.v9)(e=>e[c._.REDUX]),{companyProfileResult:n}=(0,i.v9)(e=>e[o._.REDUX]),{value:s}=(0,D.zT)(),[m,p]=(0,l.useState)([]),[y,_]=(0,l.useState)(null),[P,I]=(0,l.useState)([]);return(0,l.useEffect)(()=>{let t={dateStart:s?.[0].format(C.qx),dateEnd:s?.[1].format(C.qx)};e(k.f.getPaidServicesByDateRangeAsync(t))},[s]),(0,l.useEffect)(()=>{if((0,u.K0)(r)&&r.result){p(r.dataSource);let e=r.dataSource;(0,u.K0)(y)&&(e=e.filter(e=>e.employeeId===y?.id)),I(e)}},[r]),(0,l.useEffect)(()=>()=>{e(k.f.clearDataEmployeeTicket()),(0,u.FC)(x.uH8.VIEW_ALL_SERVICE_DETAILS),h.ZP.remove(d.P.userSerivceDetails),e(w.Xz.clearDataEmployeeTicket())},[]),(0,a.jsxs)(a.Fragment,{children:[(0,a.jsx)(g.ql,{title:"Service Details"}),(0,a.jsxs)(b.ZP,{container:!0,height:"100%",flexWrap:"nowrap",children:[(0,a.jsx)(b.ZP,{item:!0,xs:2,lg:2,height:"100%",position:"relative",children:(0,a.jsxs)(T.Wc,{heightclassic:"278px",heightlinear:"155px",sx:{display:"flex",flexDirection:"column",gap:2},children:[(0,a.jsx)(v.Z,{firstDayOfWeek:n?.weekStartsOn}),(0,a.jsx)(j.Z,{onSelect:r=>{let a=r.row,l=m?.filter(e=>e.employeeId===a?.id);_(a),I(l),e(k.f.changeEmployeeServiceDetails(a.id)),t.current="",h.ZP.set(d.P.userSerivceDetails,{id:a?.id??"",name:a?.nickName??""}),e(w.Xz.clearBillCloseTicket("dataBillServiceDetails"))}})]})}),(0,a.jsx)(b.ZP,{pl:2,item:!0,xs:7.5,lg:7.5,children:(0,a.jsx)(T.Wc,{heightlinear:"155px",children:(0,a.jsx)(f.x4,{children:(0,a.jsx)(E,{data:P,allTechnician:!0,handleOnRowClick:r=>{if(t.current!==r?.id){t.current=r?.id??"";let a={ticketId:r?.row.ticketId??"",updatedAt:r?.row?.updatedAt??null,customerId:r?.row?.customerId??""};e(w.Xz.renderBillCloseTicket({keyData:"dataBillServiceDetails",data:a}))}}})})})}),(0,a.jsx)(b.ZP,{pl:2,item:!0,xs:2.5,lg:2.5,children:(0,a.jsx)(T.Wc,{children:(0,a.jsx)(f.x4,{backgroundTab:!1,isScroll:!0,sx:{overflow:"hidden auto","&::-webkit-scrollbar":{display:"none"}},children:(0,a.jsx)(S,{id:t.current})})})})]})]})},{})}),VIEW_ONLY_SERVICE_DETAILS:(0,a.jsx)(D.Fo,{children:(0,a.jsx)(({isOpen:e,handlePrintTechnician:t})=>{let r=(0,l.useRef)(""),n=(0,i.I0)(),{value:s}=(0,D.zT)(),{getDataResult:o}=(0,i.v9)(e=>e[c._.REDUX]),m=h.ZP.get(d.P.userSerivceDetails),[p,x]=(0,l.useState)([]);return(0,l.useEffect)(()=>{r.current=""},[p]),(0,l.useEffect)(()=>{let e={employeeId:m?.id??"",dateStart:s?.[0].format(C.qx),dateEnd:s?.[1].format(C.qx)};n(k.f.getPaidServiceAsync(e))},[s]),(0,l.useEffect)(()=>{(0,u.K0)(o)&&o.result&&x(o.dataSource)},[o]),(0,l.useEffect)(()=>()=>{(0,u.FC)(I.uH.VIEW_ONLY_SERVICE_DETAILS),n(k.f.clearDataEmployeeTicket()),h.ZP.remove(d.P.userSerivceDetails),n(w.Xz.clearDataEmployeeTicket())},[]),(0,a.jsxs)(a.Fragment,{children:[(0,a.jsx)(g.ql,{title:"Service Details"}),(0,a.jsxs)(b.ZP,{container:!0,height:"100%",flexWrap:"nowrap",children:[(0,a.jsx)(b.ZP,{item:!0,xs:9.5,lg:9.5,children:(0,a.jsx)(T.Wc,{heightclassic:"192px",heightlinear:"155px",children:(0,a.jsx)(f.x4,{children:(0,a.jsx)(E,{data:p,allTechnician:!1,handleOnRowClick:e=>{if(r.current!==e?.id){r.current=e?.id??"";let t={ticketId:e?.row.ticketId??"",updatedAt:e?.row?.updatedAt??null,customerId:e?.row?.customerId??""};n(w.Xz.renderBillCloseTicket({keyData:"dataBillServiceDetails",data:t}))}}})})})}),(0,a.jsx)(b.ZP,{pl:2,item:!0,xs:2.5,lg:2.5,children:(0,a.jsx)(T.Wc,{children:(0,a.jsx)(f.x4,{isScroll:!0,sx:{overflow:"hidden auto","&::-webkit-scrollbar":{display:"none"}},children:(0,a.jsx)(S,{id:r.current})})})})]})]})},{})}),checkRole:!0}),O=(e,t,r)=>{let a="",l=0,i=0,n=0;return(e||[]).forEach((e,t,r)=>{i+=e.nonCashTip,n+=e.originalPrice,l+=e.qty,a+=`<tr class="${0===t?"bold-start":t===r.length-1?"bold-end":""}">
			<td class="name">${e.menuItemType===x.UIn.ServicePackageItem||e.menuItemType===x.UIn.PrePaidPackageItem?"==":""}${e.itemName}</td>
			<td class="right-align right-qty">${e.qty}</td>
			<td class="right-align">${(0,u.xG)(e.nonCashTip)}</td>
			<td class="right-align">${(0,u.xG)(e.originalPrice)}</td>
		</tr>`}),`<html>
					<style>
						 .class-address {
							text-align: center;
							margin-top: 0px;
							margin-bottom: 0px;
							line-height: 1.2;
						}

						.table-business {
							width: 100%;
							border-collapse: collapse;
							table-layout: fixed; 
						}

						.dashed-service {
							border-top: 1px dashed black;
							border-bottom: 1px dashed black;
							margin: 10px 0;
						}

						.name {
							text-align: left;
							width: 40%;
						}

						.right-align {
							text-align: right;
							vertical-align: top;
							width: 25%; 
						}

						.center-align {
							text-align: center;
						}

						.border-top {
							border-top: 1px dashed black;
						}

						.border-end {
							border-top: 2px dashed black;
							padding-top: 5px;
						}

						.bold-end>td {
							padding-bottom: 5px
						}

						.bold-first>td {
							padding-bottom: 8px
						}

						.bold-start>td {
							padding-top: 8px
						}

						.container-print {
							font-size: 20px;
							font-family: Verdana;
						}

						.container-print {
							font-size: 25px;
						}

						.table-business {
							font-size: 25px;
						}
						.right-qty{
							width:10%
						}
					</style>
					<body>
						<div class='container-print'>
						<p class='class-address'>${t?.businessName??""}</p>
						<p class='class-address'>${t?.address?.address??""}<br>${t?.address?.city}, ${t?.address?.state} ${t?.address?.zip}<br>${(0,N.un)(t?.phone??"")}</p>
						<table class="table-business">
							<tr>
								<td class="name">Business Date</td>
								<td class="right-align" colspan="3">${A()(new Date).format(C.GG)}</td>
							</tr>
							<tr>
								<td class="name">Technician Name</td>
								<td class="right-align" colspan="3">${r}</td>
							</tr>
						</table>
						<table class="table-business">
							<tr class="bold-first">
								<td class="name">Service/Prod</td>
								<td class="right-align right-qty">Qty</td>
								<td class="right-align">Tip</td>
								<td class="right-align">Total</td>
							</tr>
							<tr class="border-end">

							</tr>
							${a}
							<tr class="border-end">
							</tr>
							<tr class="bold-start">
								<td class="name">TOTAL</td>
								<td class="right-align right-qty">${l}</td>
								<td class="right-align">${(0,u.xG)(i)}</td>
								<td class="right-align">${(0,u.xG)(n)}</td>
							</tr>
						</table>
						</div>
					</body>
				</html>`},F=s()(()=>Promise.all([r.e(7013),r.e(3569),r.e(1873),r.e(4644),r.e(5869),r.e(2216),r.e(4022),r.e(6266),r.e(5675),r.e(1290),r.e(2129),r.e(4420),r.e(5465),r.e(1989),r.e(4801),r.e(2907),r.e(2176),r.e(5109),r.e(8413),r.e(3997),r.e(7592),r.e(5908),r.e(2433)]).then(r.bind(r,74550)),{loadableGenerated:{webpack:()=>[74550]},ssr:!1});var W=()=>{let e;let[t,r]=(0,l.useState)(!1),{companyProfileResult:n}=(0,i.v9)(e=>e[o._.REDUX]),{getDataResult:s,employeeServiceDetails:p}=(0,i.v9)(e=>e[c._.REDUX]),g=()=>{let e=(s?.dataSource??[]).filter(e=>e?.employeeId===h.ZP.get(d.P.userSerivceDetails)?.id);if(!(0,u.QC)(e))return;let t=O(e,n,h.ZP.get(d.P.userSerivceDetails)?.name??"").replace("</style>",` .container-print {
				font-size: 27px;
				}
			.table-business{
				font-size: 27px;
				}		
			</style>`);(0,u.b5)(t)},f=(0,l.useMemo)(()=>{let e=(s?.dataSource??[]).filter(e=>e?.employeeId===p);return!(0,u.QC)(e)},[p,s]),b=h.ZP.get(d.P.userSerivceDetails);return e=(0,a.jsx)(Z,{handlePrintTechnician:g,isOpen:t}),(0,a.jsx)(a.Fragment,{children:(0,a.jsx)(F,{title:"Service Details",visibleTitle:!0,subTitle:b?.name??"ALL",RightCompoent:[(0,a.jsx)(m.Z,{className:"button-tab",sx:{width:"max-content !important",...f&&{background:"#E6F1FB !important",color:"#A1C9EF !important"}},onClick:g,text:"PRINT TECHNICIAN"})],children:e})})}},5152:function(e,t,r){e.exports=r(32602)}},function(e){e.O(0,[6481,9774,2888,179],function(){return e(e.s=45370)}),_N_E=e.O()}]);